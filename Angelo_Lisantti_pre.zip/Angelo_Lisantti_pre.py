# Sistema de Registro de Notas Académicas

# ----------------------------
# CANTIDAD DE EXÁMENES
# ----------------------------

while True:
    cantidad = input("Ingrese la cantidad de exámenes (entre 1 y 10): ")

    if cantidad == "":
        print("Error: El valor no puede estar vacío.")
    elif not cantidad.isdigit():
        print("Error: Ingresó un carácter no numérico.")
    else:
        cantidad = int(cantidad)

        if cantidad < 1 or cantidad > 10:
            print("Error: La cantidad debe estar entre 1 y 10.")
        else:
            break

# ----------------------------
# INICIALIZACIÓN DE VARIABLES
# ----------------------------

contador = 1
acumulador = 0
aprobadas = 0
desaprobadas = 0
nota_mayor = 0
nota_menor = 0

# ----------------------------
# INGRESO DE NOTAS
# ----------------------------

while contador <= cantidad:

    while True:

        nota = input("Ingrese la nota del examen " + str(contador) + ": ")

        if nota == "":
            print("Error: El valor no puede estar vacío.")
        else:

            puntos = 0
            valido = True

            for caracter in nota:
                if caracter == ".":
                    puntos += 1
                elif not caracter.isdigit():
                    valido = False

            if not valido or puntos > 1:
                print("Error: Ingresó un carácter no numérico.")
            else:

                if nota == ".":
                    print("Error: Ingresó un formato inválido.")
                else:

                    if "." in nota:
                        partes = nota.split(".")

                        if partes[0] == "" and partes[1] == "":
                            print("Error: Ingresó un formato inválido.")
                        else:
                            nota = float(nota)

                            if nota < 0 or nota > 10:
                                print("Error: La nota debe estar entre 0 y 10.")
                            else:
                                break
                    else:
                        nota = float(nota)

                        if nota < 0 or nota > 10:
                            print("Error: La nota debe estar entre 0 y 10.")
                        else:
                            break

    # Procesamiento inmediato

    acumulador += nota

    if contador == 1:
        nota_mayor = nota
        nota_menor = nota
    else:
        if nota > nota_mayor:
            nota_mayor = nota

        if nota < nota_menor:
            nota_menor = nota

    if nota >= 6:
        aprobadas += 1
    else:
        desaprobadas += 1

    contador += 1

# ----------------------------
# CÁLCULO DEL PROMEDIO
# ----------------------------

promedio = acumulador / cantidad

# ----------------------------
# CONDICIÓN FINAL
# ----------------------------

if promedio >= 7:
    condicion = "Promocionado"
elif promedio >= 4:
    condicion = "Regular"
else:
    condicion = "Libre"

# ----------------------------
# REPORTE
# ----------------------------

print("\n========== REPORTE ==========")
print("Nota más alta:", nota_mayor)
print("Nota más baja:", nota_menor)
print("Promedio:", round(promedio, 2))
print("Notas aprobadas:", aprobadas)
print("Notas desaprobadas:", desaprobadas)
print("Condición final:", condicion) 